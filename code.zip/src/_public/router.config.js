export const LOGIN_MENUS = [{
    title: '菜单',
    children: [{ title: '登入', name: 'Login', path: '/login' }]
}, {
    title: '帮助',
    children: [
        { title: '说明书', Href: 'https://www.shukiin.com/manual/' },
        { title: '联络我们', Href: 'https://www.shukiin.com/inquiry/' }
    ]
}];

