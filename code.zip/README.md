下载Visual studio code, NodeJS

1. 安装依赖包
    终端进入当前项目目录，执行 npm install

2. 启动项目
    终端进入当前项目目录，执行 npm run serve